package net.steve.expandedsurvival;

import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.steve.expandedsurvival.init.BlockInit;
import net.steve.expandedsurvival.villager.ModVillagers;

@Mod.EventBusSubscriber(modid = ExpandedSurvival.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModCommonEvents {


}
